<?php
//if (!isset($_SESSION["currentUser"])) 
  //   header("Location: signIn.php");
 
session_start();
   unset($_SESSION["currentUser"]);
   unset($_SESSION["currentUserID"]);
   //var_dump($_POST);
		if (isset($_POST['Submit'])) {
			
			
	
			$formUser=$_POST["Username"];
			//var_dump('xxxxxxxxxxxxxxxxx');
			$formPass=$_POST["Password"];

			include("dbConnect.php");
		
			$dbQuery=$conn->prepare("select * from Users where Username=:formUser"); 
			$dbParams=array('formUser'=>$formUser);
			$dbQuery->execute($dbParams);
			$dbRow = $dbQuery->fetch(PDO::FETCH_ASSOC);
			
			//print_r($dbRow);
			
			
			//var_dump('SELECTED VALUES');
			if ($dbRow["Username"]==$formUser) {       
				if ($dbRow["Password"]==$formPass) {
					$_SESSION["currentUser"]=$formUser;
					$_SESSION["currentUserID"]=$dbRow["User_ID"];
					//var_dump("TRUE");
					header("Location: userprofilepage.php");
				}
				else {
					var_dump("FALSE");
					header("Location: signIn.php?failCode=2");
				}
			} else {
				var_dump("FALSE");
				header("Location: signIn.php?failCode=1");
			}

		} 
else {
?>
<html lang="en">
  <head>
    <title>Digital Memories</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
  </head>
  <body class="bg-info">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="/">Digital Memories</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.html">Home<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="register.php">Register</a>
      </li>
      
      
    </ul>
  </div>
</nav>
	
	<div class="container">
			<div class="row main">
				<div class="main-login main-center">
				<h5>Sign in to account<h5>
				
				<?php
  if (isset($_GET["failCode"])) {
      if ($_GET["failCode"]==1)
         echo "<h3>Incorrect Username entered</h3>";
      if ($_GET["failCode"]==2)
         echo "<h3>Incorrect Password entered</h3>";
   }      
?>  
							<form id='login' action='<?php echo($_SERVER['PHP_SELF']) ?>' method='post' accept-charset='UTF-8'>
<fieldset >
<legend>Login</legend>

<label for='username' >UserName*:</label>
<input type='text' required name='Username' id='Username'  maxlength="50" />

<label for='password' >Password*:</label>
<input type='password' required name='Password' id='Password' maxlength="50" />

<input type='submit' name='Submit' value='Submit' />

</fieldset>
</form>
						</div>
						
					</form>
				</div>
			</div>
		</div>
  <h3></h3>
  <p></p>
</div>

</body>
</html>
</head>
<?php
}
?>

