<?php
			require 'mainHeader.html';
			if (!isset($_SESSION["currentUser"])) 
            header("Location: login.php");
		    session_start();
			include("dbConnect.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>



<div class="container">

<button onclick="myFunction()">Print this page</button>

<script>
function myFunction() {
    window.print();
}
</script>

<center><h2> Looking after someone can be tough. Here is a quick guide to
ten of the key challenges that caring can throw your way...
Getting the right advice and information... quickly! </h2>

<style>
div.a {
    text-align: center;
}


div.d {
    text-align: justify;
} 

p {
    font-family: "Times New Roman", Times, serif;
}
</style>

<div class="container">
<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo">1.Getting the right advice and information.. quickly! </button>
<div id="demo" class="collapse">
<p>Caring can be extermely complicated, whether we're grappling with the benfits system or considering how to pay for care. Each strand is confussing but when all the strands 
is confusing but when all the strands are tangled, it can feel bewildering. Turning to an expert can help to unravel the most complex situation.</p>
</div>
</div>
<br>
<br>


<div class="container">
<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo1"> 2. Coping with feelings of guilt </button>
<div id="demo1" class="collapse">
<p>When were looking after someone, it's important to accept that guilt is normal and that we only feel it because we can. Being able to
talk to people who understand what we're going through and how we feel can help us handle our feelings of guilt better. </p>
</div>
</div>

<br>
<br>


<div class="container">
<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo2">3. Being assertive with professionals </button>
<div id="demo2" class="collapse">
<p>Looking after somone will often involve dealing with several different professionals. When we feel a professional
has not explained things clearly, does not see the whole picture or prehaps is not doing what we need to do.
And this starts with valuing ourselves and our caring role. </p>
</div>
</div>

<br>
<br>


<div class="container">
<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo3">4. Handling difficult conversations</button>
<div id="demo3" class="collapse">
<p>Even a tricky conversation with professionals can be a breeze compared to having to deal with family and friends.
We may have to ask a sibling to be more supportive, remind a friend that we still exist or talk gently to a a parent
who doesn't accept that they can't live independently any longer. This takes courage, bags or patience and tact. 
Talking it through with people outside the situatuion can make a world of difference.</p>
</div>
</div>
<br>
<br>


<div class="container">
<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo4">4. Handling difficult conversations</button>
<div id="demo4" class="collapse">
<p>As carers, we may have immediate needs sich as taking breaks, getting sleep, eating properlu or exercising. We may have
longer-term needs such as building fulfilling realtionships, pursuing hobbies or developing careers. </p>
</div>
</div>

<br>
<br>


<div class="container">
<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo5">6. Noticing when we're too stressed</button>
<div id="demo5" class="collapse">
<p>Stress can alert us to potiental dangers and spur us on to achieve a goal. Howver, sometimes the balance tips too far 
and the pressure becomes so intense or presistent that we may feel unable to cope. 
As soon as we notice it getting too much, it's helpful to talk about how we feel rather than hoping the stress will go away. </p>
</div>
</div>

<br>
<br>



<div class="container">
<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo5">7. Making difficult decisions</button>
<div id="demo5" class="collapse">
<p>There will be points when we are faced with a particulary emotional or difficult decision. 
Sometimes its a decision we have planned for, or at least held at the back of our mind. Sometimes it's completely unexpected and leaves 
us feeling out of control. Where we can, thinking about decisions in advance can help us keep a cool head when it comes to the crunch.</p> 
</div>
</div>

<br>
<br>



<div class="container">
<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo6">8. Keeping relationships fulfilling  </button>
<div id="demo6" class="collapse">
<p>Caring for our loved ones can express the best of who we are, and can take relationship to a profound new level. It can also push us to 
the brink through financial, emotional and practical strain. Illness can cast aside the best-laid plans and make relationships feel utterly 
different. What matters most most is that there's way for us to talk honestly and find help when we need it. </p>
</div>
</div>

<br>
<br>


<div class="container">
<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo7">9. Adapting to changing circumstances </button>
<div id="demo7" class="collapse">
<p> Whether we're looking after someone who's recovering or whose condition is deteriorating over time, caring inevitably involves adapting to 
circumstances. 
Sometime its easy to focus on the practical details - the administration of care workers or move to the care home. Being able to stay 
attentive to our relationship with the person we're caring for in th midst of all that change is far from easy.</p>
</div>
</div>

<br>
<br>


<div class="container">
<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo8">10. Kepping a sense of humour</button>
<div id="demo8" class="collapse">
<p>Nothing relives stress and tension better tahn a good laugh.
Sometimes caring can feel a bit like starring in our own sitcom, and theres no shortage of comedy material. Other times we may need a bit of help 
finding someting to laugh about. Either way, sharing experiences with other carers is often great not just for feeling listened to and understood but for 
finding the humour that can keep us going. </p>

</div>
</div>
 

 
